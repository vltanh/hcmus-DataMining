=============
ARFF Datasets
=============

The collection of ARFF datasets of the Connectionist Artificial Intelligence Laboratory (LIAC)
- http://inf.ufrgs.br/liac

Pull request to add or modify something!
