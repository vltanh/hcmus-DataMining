﻿Mã nguồn chương trình nằm ở tập tin1612838_1612849.py. Để chạy chương trình cần càiđặt Python 3 và thư viện numpy:
	pip3 install numpy
Chuơng trình có thể chạy bằng dòng lệnh Terminal
	python3 1612838_1612849.py [input] [output_model] [output_asgn] [k]
Trong đó
	[input]: đường dẫn đến tập tin .csv
	[output_model]: đường dẫn đến nơi lưu model.txt
	[output_asgn]: đường dẫn đến nơi lưu assignment.csv
	[k]: số cụm mong muốn
Ví dụ
	python3 1612838_1612849.py ../data/session.csv model.txt assignments.csv 2
